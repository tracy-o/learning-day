# How Many Instances do we Need on Sydney?

The purposes of these loadtests are twofold:
- to determine the base instances on sydney
- to see how our performance has changed since introducing [Finch](https://jira.dev.bbc.co.uk/browse/RESFRAME-4765), [OPT 24](https://jira.dev.bbc.co.uk/browse/RESFRAME-4503) and  [increasing the somaxconn value](https://jira.dev.bbc.co.uk/browse/RESFRAME-4791)

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=2500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_2500_rps__100msl_results.bin | vegeta report
Thu 28 Jul 12:23:27 UTC 2022
Requests      [total, rate, throughput]  750000, 2500.00, 2499.11
Duration      [total, attack, wait]      5m0.105832507s, 4m59.99961052s, 106.221987ms
Latencies     [mean, 50, 95, 99, max]    106.539603ms, 106.060456ms, 107.887261ms, 113.254912ms, 30.000134942s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:2  200:749998
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=2500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_2500_rps_200msl_results.bin | vegeta report
Thu 28 Jul 14:21:39 UTC 2022
Requests      [total, rate, throughput]  1500000, 2500.00, 2499.03
Duration      [total, attack, wait]      10m0.228909542s, 9m59.999631811s, 229.277731ms
Latencies     [mean, 50, 95, 99, max]    206.783958ms, 206.184248ms, 208.042701ms, 212.895201ms, 30.00014038s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:11  200:1499989
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=2500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_2500_rps_1000msl_results.bin | vegeta report
Thu 28 Jul 15:52:50 UTC 2022
Requests      [total, rate, throughput]  750000, 2500.00, 2287.37
Duration      [total, attack, wait]      5m27.54691606s, 4m59.999662402s, 27.547253658s
Latencies     [mean, 50, 95, 99, max]    1.17723455s, 1.008267631s, 1.129914385s, 5.649632415s, 30.006397807s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    99.90%
Status Codes  [code:count]               0:778  200:749222
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: EOF
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=2000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_2000_rps_100msl_results.bin | vegeta report
Thu 28 Jul 16:16:56 UTC 2022
Requests      [total, rate, throughput]  600000, 2000.00, 1999.30
Duration      [total, attack, wait]      5m0.105071147s, 4m59.999493543s, 105.577604ms
Latencies     [mean, 50, 95, 99, max]    106.078112ms, 105.830372ms, 107.263318ms, 110.084572ms, 1.162465248s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:600000
Error Set:
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=1500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_1500_rps_100msl_results.bin | vegeta report
Thu 28 Jul 16:07:50 UTC 2022
Requests      [total, rate, throughput]  450001, 1500.00, 1499.47
Duration      [total, attack, wait]      5m0.104819269s, 4m59.999690395s, 105.128874ms
Latencies     [mean, 50, 95, 99, max]    106.089981ms, 105.661407ms, 106.891272ms, 109.048237ms, 30.000144025s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:3  200:449998
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=360s -rate=1500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_360s_1500_rps_100msl_results.bin | vegeta report
Thu 28 Jul 16:26:19 UTC 2022
Requests      [total, rate, throughput]  540001, 1500.00, 1499.57
Duration      [total, attack, wait]      6m0.104950908s, 5m59.999617762s, 105.333146ms
Latencies     [mean, 50, 95, 99, max]    105.817774ms, 105.66324ms, 106.851806ms, 108.962474ms, 360.120548ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:540001
Error Set:
```

```
$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=3000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_3000_rps_100msl_results.bin | vegeta report
Thu 28 Jul 17:36:55 UTC 2022
Requests      [total, rate, throughput]  900001, 3000.01, 2935.61
Duration      [total, attack, wait]      5m6.578849709s, 4m59.999764004s, 6.579085705s
Latencies     [mean, 50, 95, 99, max]    108.29322ms, 106.962418ms, 112.23323ms, 131.506289ms, 30.000597926s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:5  200:899996
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```

RPS vs CPU Usage Table
| RPS  | CPU USAGE |         |
|------|-----------|---------|
|      | Trial 1   | Trial 2 |
| 1500 | 82.2%     | 82.3%   |
| 2000 | 87.3%     | 87.2%   |
| 2500 | 89.2%     | 91.3%   |
| 300  | fails*    | -       |


Latency vs Pool Workers Table
The rps was a constant 2500rps for at least 5 mins each time.

| Latency (ms) | Min Workers Per Pool | Total Workers (*8) |
|--------------|----------------------|--------------------|
| 100          | 28                   | 224                |
| 150          | 42                   | 336                |
| 200          | 57                   | 456                |
| 500          | 149                  | 1,192              |
| 1000*        | 304                  | 2,432              |


---

```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=1500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_1500_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 11:10:34 UTC 2022
Requests      [total, rate, throughput]  900001, 1500.00, 1499.99
Duration      [total, attack, wait]      10m0.003282699s, 9m59.999437557s, 3.845142ms
Latencies     [mean, 50, 95, 99, max]    6.010134ms, 3.817463ms, 4.975599ms, 106.506928ms, 312.82823ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:900001
Error Set:
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=2000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_2000_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 11:35:01 UTC 2022
Requests      [total, rate, throughput]  1200000, 2000.00, 1999.99
Duration      [total, attack, wait]      10m0.003024056s, 9m59.99949827s, 3.525786ms
Latencies     [mean, 50, 95, 99, max]    6.149425ms, 3.950069ms, 5.211724ms, 106.790779ms, 359.430179ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:1200000
Error Set:
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=2500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_2500_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 12:11:45 UTC 2022
Requests      [total, rate, throughput]  1500000, 2500.00, 2499.98
Duration      [total, attack, wait]      10m0.004057703s, 9m59.999641071s, 4.416632ms
Latencies     [mean, 50, 95, 99, max]    6.349062ms, 4.105123ms, 5.54578ms, 107.306579ms, 30.000142591s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:1  200:1499999
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=3000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_3000_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 12:29:59 UTC 2022
Requests      [total, rate, throughput]  1800002, 3000.00, 2999.98
Duration      [total, attack, wait]      10m0.004525255s, 9m59.999782739s, 4.742516ms
Latencies     [mean, 50, 95, 99, max]    6.680528ms, 4.211617ms, 6.253069ms, 109.826973ms, 30.000131632s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:2  200:1800000
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=3500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_3500_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 12:45:34 UTC 2022
Requests      [total, rate, throughput]  2100002, 3500.00, 3499.95
Duration      [total, attack, wait]      10m0.006199114s, 9m59.999759523s, 6.439591ms
Latencies     [mean, 50, 95, 99, max]    8.521788ms, 4.393234ms, 16.669126ms, 122.701484ms, 30.000662275s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:9  200:2099993
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=3500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_3500_rps_100msl_ttl5_results2.bin | vegeta report
Fri 29 Jul 13:22:48 UTC 2022
Requests      [total, rate, throughput]  2100002, 3500.00, 3499.97
Duration      [total, attack, wait]      10m0.00385826s, 9m59.999754033s, 4.104227ms
Latencies     [mean, 50, 95, 99, max]    7.517117ms, 4.228181ms, 9.216739ms, 117.700166ms, 30.000142253s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:6  200:2099996
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=4000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_4000_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 13:47:01 UTC 2022
^CRequests      [total, rate, throughput]  359176, 4000.01, 3999.78
Duration      [total, attack, wait]      1m29.797837386s, 1m29.79373387s, 4.103516ms
Latencies     [mean, 50, 95, 99, max]    10.374359ms, 4.8441ms, 29.563503ms, 133.171137ms, 30.000143709s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:4  200:359172
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=4000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_4000_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 14:31:41 UTC 2022
Requests      [total, rate, throughput]  2400000, 4000.00, 3999.95
Duration      [total, attack, wait]      10m0.006045559s, 9m59.999818992s, 6.226567ms
Latencies     [mean, 50, 95, 99, max]    8.746838ms, 4.434084ms, 21.581788ms, 129.494672ms, 30.000146345s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               0:8  200:2399992
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
```
```
[chris_hopkins01@ip-10-114-174-6 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=600s -rate=4500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_600s_4500_rps_100msl_ttl5_results.bin | vegeta report
Fri 29 Jul 15:00:58 UTC 2022
Requests      [total, rate, throughput]  2690440, 4487.35, 4092.73
Duration      [total, attack, wait]      10m29.533454944s, 9m59.560696894s, 29.97275805s
Latencies     [mean, 50, 95, 99, max]    776.679523ms, 6.811276ms, 3.146221826s, 21.66610463s, 36.398112624s
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    95.77%
Status Codes  [code:count]               0:31412  200:2576509  500:82519
Error Set:
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled (Client.Timeout exceeded while awaiting headers)
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: EOF
500 Internal Server Error
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: dial tcp 0.0.0.0:0->34.245.251.89:443: bind: address already in use
read tcp 10.114.174.6:58402->52.212.83.170:443: read: connection reset by peer
read tcp 10.114.174.6:46407->52.212.83.170:443: read: connection reset by peer
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: dial tcp 0.0.0.0:0->54.220.222.39:443: bind: address already in use
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: net/http: request canceled while waiting for connection (Client.Timeout exceeded while awaiting headers)
read tcp 10.114.174.6:25242->52.212.83.170:443: read: connection reset by peer
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: dial tcp 0.0.0.0:0->52.212.83.170:443: bind: address already in use
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: http: server closed idle connection
Get https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator: EOF (Client.Timeout exceeded while awaiting headers)
net/http: request canceled (Client.Timeout exceeded while reading body)
```

ssh 10.114.175.63,eu-west-1
Warning: Permanently added '10.114.175.63,eu-west-1' (ECDSA) to the list of known hosts.
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_500_rps_100msl_results.bin | vegeta report
Mon  1 Aug 11:18:29 UTC 2022
Requests      [total, rate, throughput]  150000, 500.00, 499.83
Duration      [total, attack, wait]      5m0.103920689s, 4m59.997991281s, 105.929408ms
Latencies     [mean, 50, 95, 99, max]    105.779173ms, 105.801448ms, 106.766906ms, 108.61979ms, 362.727471ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:150000
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=250 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_250_rps_100msl_results.bin | vegeta report
Mon  1 Aug 11:27:59 UTC 2022
Requests      [total, rate, throughput]  75000, 250.00, 249.92
Duration      [total, attack, wait]      5m0.101563199s, 4m59.995956418s, 105.606781ms
Latencies     [mean, 50, 95, 99, max]    105.815377ms, 105.67641ms, 106.643861ms, 107.947733ms, 316.004374ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:75000
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=750 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_750_rps_100msl_results.bin | vegeta report
Mon  1 Aug 11:57:22 UTC 2022
Requests      [total, rate, throughput]  225001, 750.00, 749.74
Duration      [total, attack, wait]      5m0.104834315s, 4m59.999920607s, 104.913708ms
Latencies     [mean, 50, 95, 99, max]    105.711426ms, 105.565456ms, 106.653162ms, 108.724579ms, 357.705158ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:225001
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=1000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_1000_rps_100msl_results.bin | vegeta report
Mon  1 Aug 12:07:12 UTC 2022
Requests      [total, rate, throughput]  300000, 1000.00, 999.65
Duration      [total, attack, wait]      5m0.104110851s, 4m59.99899453s, 105.116321ms
Latencies     [mean, 50, 95, 99, max]    105.539285ms, 105.225797ms, 106.606569ms, 108.712768ms, 358.332228ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:300000
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=250 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_250_rps_100msl__ttl5_results.bin | vegeta report
Mon  1 Aug 12:19:50 UTC 2022
Requests      [total, rate, throughput]  75000, 250.00, 250.00
Duration      [total, attack, wait]      4m59.999405201s, 4m59.995982637s, 3.422564ms
Latencies     [mean, 50, 95, 99, max]    5.759464ms, 3.509192ms, 4.637778ms, 106.097626ms, 216.304632ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:75000
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=500 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_500_rps_100msl__ttl5_results.bin | vegeta report
Mon  1 Aug 12:29:00 UTC 2022
Requests      [total, rate, throughput]  150000, 500.00, 500.00
Duration      [total, attack, wait]      5m0.002158355s, 4m59.997998395s, 4.15996ms
Latencies     [mean, 50, 95, 99, max]    5.743879ms, 3.51175ms, 4.614639ms, 106.468132ms, 316.933871ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:150000
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=750 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_750_rps_100msl_ttl5_results.bin | vegeta report
Mon  1 Aug 12:38:27 UTC 2022
Requests      [total, rate, throughput]  225001, 750.00, 750.00
Duration      [total, attack, wait]      5m0.003333008s, 4m59.999892847s, 3.440161ms
Latencies     [mean, 50, 95, 99, max]    5.804875ms, 3.595305ms, 4.717537ms, 106.24052ms, 357.428532ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:225001
Error Set:
[chris_hopkins01@ip-10-114-175-63 ~]$ date && echo "GET https://sydney.belfrage.test.api.bbc.co.uk/origin-simulator" | vegeta attack -duration=300s -rate=1000 -max-body=0 -header "replayed-traffic:true" -header "accept-encoding:gzip" -http2=false | tee sydney_300s_1000_rps_100msl_ttl5_results.bin | vegeta report
Mon  1 Aug 12:47:37 UTC 2022
Requests      [total, rate, throughput]  300000, 1000.00, 999.99
Duration      [total, attack, wait]      5m0.00241461s, 4m59.998999719s, 3.414891ms
Latencies     [mean, 50, 95, 99, max]    5.94215ms, 3.724063ms, 5.005134ms, 106.358623ms, 352.911313ms
Bytes In      [total, mean]              0, 0.00
Bytes Out     [total, mean]              0, 0.00
Success       [ratio]                    100.00%
Status Codes  [code:count]               200:300000
Error Set: