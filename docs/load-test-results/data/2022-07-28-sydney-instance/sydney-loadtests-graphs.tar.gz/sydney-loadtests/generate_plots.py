#!/usr/bin/env python3

import sys
import os
import glob

bin_files = glob.glob('*.bin')

plot_files = list(map(lambda f: os.path.splitext(f)[0]+'.html', bin_files))

for bin,plot in zip(bin_files, plot_files):
    command = f"cat {bin} | vegeta plot > {plot}"
    print(command)
    os.system(command)

